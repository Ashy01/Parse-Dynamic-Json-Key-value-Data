package com.example.ashish.parsedynamicjson;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;


import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {
    ProgressDialog pDialog;
    private LinearLayoutManager linearLayoutManagerHorizontal;
    private ExpandableListView expandableListView;

    SwipeRefreshLayout mSwipeRefreshLayout;

    private static final String TAG = MainActivity.class.getSimpleName();

    ArrayList<GroupModel> arrayListGroup = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pDialog = new ProgressDialog(this);
        expandableListView = findViewById(R.id.mainList);
        new GetCategory().execute();
    }

    private class GetCategory extends AsyncTask<Void, Void, Void> {
        String url = "http://avaa.co.in/api/category.php";

        String jsonResponse = "";
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);

            if (jsonStr != null) {

                jsonResponse = jsonStr;
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();
            parsJson(jsonResponse);

        }

    }



    private void parsJson(String strJsonResponse) {
        try {
            try {

                // Parse the data into jsonobject to get original data in form of json.
                // searchResult refers to the current element in the array "search_result"
                //JSONObject objMainJson = searchResult.getJSONObject("question_mark");

                arrayListGroup = new ArrayList<>();
                JSONObject objMainJson = new JSONObject(strJsonResponse);
                Iterator keyMainJson = objMainJson.keys();
                while (keyMainJson.hasNext()) {
                    // loop to get the dynamic key
                    String currentDynamicKey = (String) keyMainJson.next();


                    // get the value of the dynamic key
                    JSONObject currentDynamicValue = objMainJson.getJSONObject(currentDynamicKey);


                    GroupModel groupModel = new GroupModel("", currentDynamicKey, "1");


                    String id = currentDynamicValue.getString("id");
                    groupModel.id = id;
                    String name = currentDynamicValue.getString("name");
                    groupModel.name = name;




                    ArrayList<ChildModel> arrayListChildModel = new ArrayList<>();

                    Iterator keyMainJson1 = currentDynamicValue.keys();
                    while (keyMainJson1.hasNext()) {
                        // loop to get the dynamic key
                        String currentDynamicKey1 = (String) keyMainJson1.next();


                        if (currentDynamicKey1.contains("childs")) {

                            // get the value of the dynamic key
                            JSONObject currentDynamicValue1 = currentDynamicValue.getJSONObject(currentDynamicKey1);

                            // do something here with the value...

                            Iterator keyMainJson2 = currentDynamicValue1.keys();
                            while (keyMainJson2.hasNext()) {
                                // loop to get the dynamic key
                                String currentDynamicKey2 = (String) keyMainJson2.next();

                                                    ChildModel childModel = new ChildModel("", currentDynamicKey2, "2");
                                ArrayList<SubChildModel> arrayListSubChildModel = new ArrayList<>();

                                //if(currentDynamicKey2.contains("childs"))
                                {
                                    // get the value of the dynamic key
                                    JSONObject currentDynamicValue2 = currentDynamicValue1.getJSONObject(currentDynamicKey2);
                                                       // do something here with the value...

                                    String subId = currentDynamicValue2.getString("id");
                                    childModel.id = subId;
                                    String subName = currentDynamicValue2.getString("name");
                                    childModel.name = subName;


                                    Iterator keyMainJson3 = currentDynamicValue2.keys();
                                    while (keyMainJson3.hasNext()) {
                                        // loop to get the dynamic key
                                        String currentDynamicKey3 = (String) keyMainJson3.next();


                                        if (currentDynamicKey3.contains("childs")) {
                                            // get the value of the dynamic key
                                            JSONObject currentDynamicValue3 = currentDynamicValue2.getJSONObject(currentDynamicKey3);

                                            // do something here with the value...


                                            Iterator keyMainJson4 = currentDynamicValue3.keys();
                                            while (keyMainJson4.hasNext()) {
                                                // loop to get the dynamic key
                                                String currentDynamicKey4 = (String) keyMainJson4.next();

                                                SubChildModel subChildModel = new SubChildModel("", currentDynamicKey4, "3");


                                                //if(currentDynamicKey3.contains("childs"))
                                                {
                                                    // get the value of the dynamic key
                                                    JSONObject currentDynamicValue4 = currentDynamicValue3.getJSONObject(currentDynamicKey4);


                                                    String subsubId = currentDynamicValue4.getString("id");
                                                    subChildModel.id = subsubId;
                                                    String subsubName = currentDynamicValue4.getString("name");
                                                    subChildModel.name = subsubName;

//                                                    ClothingFragment.showLog(subsubId + "===ID==444==Name=" + subsubName);
                                                    // do something here with the value...
                                                }

                                                arrayListSubChildModel.add(subChildModel);
                                            }
                                        }
                                    }
                                }
                                childModel.arrayListSubChildModel = arrayListSubChildModel;
                                arrayListChildModel.add(childModel);
                            }

                        }
                    }

                    groupModel.arrayListChildModel = arrayListChildModel;
                    arrayListGroup.add(groupModel);

                    // do something here with the value...
                }

                // set adapter
                if(arrayListGroup !=null) {
                    expandableListView.setAdapter(new ParentLevel(this, arrayListGroup));
//                    printAllData();

                }
                else
                {
//                    ClothingFragment.showLog("====oops null data===arrayListGroup==");
                }


            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public class ParentLevel extends BaseExpandableListAdapter {

        private Context context;
        ArrayList<GroupModel> arrayListGroup = new ArrayList<>();

        public ParentLevel(Context context,ArrayList<GroupModel> arrayListGroup) {
            this.context = context;
            this.arrayListGroup = arrayListGroup;
        }

        @Override
        public Object getChild(int arg0, int arg1) {
            return arg1;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

            SecondLevelExpandableListView secondLevelELV = new SecondLevelExpandableListView(MainActivity.this);

            secondLevelELV.setAdapter(new SecondLevelAdapter(context,arrayListGroup.get(groupPosition).arrayListChildModel));
            secondLevelELV.setGroupIndicator(null);

            return secondLevelELV;

        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return 1;
        }

        @Override
        public Object getGroup(int groupPosition) {
            return groupPosition;
        }

        @Override
        public int getGroupCount() {
            return arrayListGroup.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.row_first, null);
                TextView text = convertView.findViewById(R.id.eventsListEventRowText);
                text.setText("FIRST LEVEL");

                GroupModel groupModel = arrayListGroup.get(groupPosition);
                text.setText(groupModel.name );
//                text.setText(groupModel.id + " >> " + groupModel.name );
            }
            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
    }

    public class SecondLevelExpandableListView extends ExpandableListView {

        public SecondLevelExpandableListView(Context context) {
            super(context);

        }

        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            //999999 is a size in pixels. ExpandableListView requires a maximum height in order to do measurement calculations.
            heightMeasureSpec = MeasureSpec.makeMeasureSpec(999999, MeasureSpec.AT_MOST);
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        }
    }

    public class SecondLevelAdapter extends BaseExpandableListAdapter {

        private Context context;
        ArrayList<ChildModel> arrayListChildModel = new ArrayList<>();

        public SecondLevelAdapter(Context context,ArrayList<ChildModel> arrayListChildModel) {
            this.context = context;
            this.arrayListChildModel = arrayListChildModel;
        }

        @Override
        public Object getGroup(int groupPosition) {
            return groupPosition;
        }

        @Override
        public int getGroupCount() {
            return arrayListChildModel.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.row_second, null);
                TextView text = convertView.findViewById(R.id.eventsListEventRowText);
                // text.setText("SECOND LEVEL");

                ChildModel childModel = arrayListChildModel.get(groupPosition);
                text.setText(childModel.name );
//                text.setText(childModel.id + " >> " + childModel.name );
            }
            return convertView;
        }

        @Override
        public Object getChild(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(R.layout.row_third, null);
                TextView text = convertView.findViewById(R.id.eventsListEventRowText);
                //text.setText("THIRD LEVEL");
                SubChildModel subChildModel = arrayListChildModel.get(groupPosition).arrayListSubChildModel.get(childPosition);
//                text.setText(subChildModel.id + " >> " + subChildModel.name );
                text.setText("          "+subChildModel.name );

                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
//                        Intent intent =new Intent(getActivity(), ProductByCatList.class);
//                        intent.putExtra("EXTRA_SESSION_ID",subChildModel.id);
//                        startActivity(intent);
                    }
                });

            }


            return convertView;
        }

        @Override
        public int getChildrenCount(int groupPosition) {
            return arrayListChildModel.get(groupPosition).arrayListSubChildModel.size();
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }
    }

    class GroupModel {

        String id = "";
        String name = "";
        String level = "";
        ArrayList<ChildModel> arrayListChildModel = new ArrayList<>();

        public GroupModel(String id, String name, String level) {
            this.id = id;
            this.name = name;
            this.level = level;
        }
    }

    class ChildModel {

        String id = "";
        String name = "";
        String level = "";
        ArrayList<SubChildModel> arrayListSubChildModel = new ArrayList<>();

        public ChildModel(String id, String name, String level) {
            this.id = id;
            this.name = name;
            this.level = level;
        }
    }


    class SubChildModel {

        String id = "";
        String name = "";
        String level = "";

        public SubChildModel(String id, String name, String level) {
            this.id = id;
            this.name = name;
            this.level = level;
        }
    }








}
